(function(){Competitions = new Mongo.Collection('competitions');

})();
