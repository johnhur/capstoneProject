(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Chart;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt:chartjs'] = {
  Chart: Chart
};

})();

//# sourceMappingURL=mrt_chartjs.js.map
