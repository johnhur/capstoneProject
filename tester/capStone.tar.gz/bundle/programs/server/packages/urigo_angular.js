(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var LocalCollection = Package.minimongo.LocalCollection;
var Minimongo = Package.minimongo.Minimongo;
var ObserveSequence = Package['observe-sequence'].ObserveSequence;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['urigo:angular'] = {};

})();

//# sourceMappingURL=urigo_angular.js.map
